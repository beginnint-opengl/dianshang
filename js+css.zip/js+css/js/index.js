window.addEventListener('load', function() {
    var focus = this.document.querySelector('.focus');
    var row_l = this.document.querySelector('.row-l');
    var row_r = this.document.querySelector('.row-r');
    var ul = focus.querySelector('ul');
    var ol = focus.querySelector('.circle');

    focus.addEventListener('mouseenter', function() {
        row_l.style.display = 'block';
        row_r.style.display = 'block';
        clearInterval(timer);
        timer = null;
    });
    focus.addEventListener('mouseleave', function() {
        row_l.style.display = 'none';
        row_r.style.display = 'none';
        timer = setInterval(function() {
            //手动调用点击事件
            row_r.click();
        }, 2000);
    });

    for (var i = 0; i < ul.children.length; i++) {
        var li = this.document.createElement('li');
        ol.appendChild(li);
        ol.children[i].setAttribute('index', i);


        li.addEventListener('click', function() {
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            this.className = 'current';
            var focusLength = focus.offsetWidth;
            var index = this.getAttribute('index');
            circle = num = index;
            animate(ul, -index * focusLength);
        });
    }
    var newLi = ul.firstElementChild.cloneNode(true);
    ul.appendChild(newLi);
    ol.children[0].className = 'current';


    var num = 0;
    var circle = 0;
    var flag = true;
    row_r.addEventListener('click', function() {
        if (flag) {
            flag = false;
            if (num == ul.children.length - 1) {
                ul.style.left = 0;
                num = 0;
            }
            num++;
            var length = -num * focus.offsetWidth
            animate(ul, length, function() {
                flag = true;
            });

            circle++;
            if (circle == ol.children.length) {
                circle = 0;
            }

            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }


            ol.children[circle].className = 'current';
        }

    });
    row_l.addEventListener('click', function() {
        if (flag) {
            flag = false;
            if (num == 0) {
                num = ul.children.length - 1;
                ul.style.left = -num * focus.offsetWidth + 'px';
            }
            num--;
            var length = -num * focus.offsetWidth
            animate(ul, length, function() {
                flag = false;
            });

            circle--;
            if (circle < 0) {
                circle = ol.children.length - 1;
            }

            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }


            ol.children[circle].className = 'current';
        }

    });
    var timer = setInterval(function() {
        //手动调用点击事件
        row_r.click();
    }, 2000);

});