window.addEventListener('load', function() {
    var preview = this.document.querySelector('.preview_img');
    var big = this.document.querySelector('.big');
    var mask = this.document.querySelector('.mask');
    var bigImg = this.document.querySelector('.big-img');
    preview.addEventListener('mouseover', function() {
        big.style.display = 'block';
        mask.style.display = 'block';
    })

    preview.addEventListener('mouseout', function() {
        big.style.display = 'none';
        mask.style.display = 'none';
    })
    preview.addEventListener('mousemove', function(e) {

        var x = e.pageX - preview.offsetLeft;
        var y = e.pageY - preview.offsetTop;
        var maskMax = preview.offsetWidth - mask.offsetWidth;
        var maskX = x - mask.offsetWidth / 2;
        var maskY = y - mask.offsetHeight / 2;
        if (maskX <= 0) {
            maskX = 0;
        } else if (maskX > preview.offsetWidth - mask.offsetWidth) {
            maskX = preview.offsetWidth - mask.offsetWidth;
        }
        if (maskY <= 0) {
            maskY = 0;
        } else if (maskY > preview.offsetHeight - mask.offsetHeight) {
            maskY = preview.offsetHeight - mask.offsetHeight;
        }
        mask.style.top = maskY + 'px';
        mask.style.left = maskX + 'px';

        var bigMax = bigImg.offsetWidth - big.offsetWidth;
        var bigX = maskX / maskMax * bigMax;
        var bigY = maskY / maskMax * bigMax;
        bigImg.style.top = -bigY + 'px';
        bigImg.style.left = -bigX + 'px';
    })
})