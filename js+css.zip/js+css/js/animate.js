function animate(obj, target, callback) {
    obj.timer = setInterval(function() {
        var stepX = (target - obj.offsetLeft) / 10;
        if (stepX < 0) {
            stepX = Math.floor(stepX);
        } else {
            stepX = Math.ceil(stepX);
        }
        if (stepX == 0) {
            clearInterval(obj.timer);
            if (callback) {
                callback();
            }

        } else {
            obj.style.left = obj.offsetLeft + stepX + 'px';
        }
    }, 15)
}