$(function() {
    var flag = true;

    function toggleTool() {
        if ($(document).scrollTop() >= $(".recommend").offset().top) {
            $(".fixedtool").fadeIn();
        } else {
            $(".fixedtool").fadeOut();
        }
    };
    toggleTool();
    $(window).scroll(function() { //recommend fixedtool(固定定位)
        toggleTool();
        if (flag) {
            $(".floor .w").each(function(i, ele) {
                if ($(document).scrollTop() >= $(ele).offset().top) {
                    $(".fixedtool li").eq(i).addClass("current");
                    $(".fixedtool li").eq(i).siblings().removeClass("current ");
                }
            })
        }

    });
    $(".fixedtool li").click(function() {
        flag = false;
        var current = $(".floor").children().eq($(this).index()).offset().top;
        $("body,html").stop().animate({
            scrollTop: current
        }, 1000, function() {
            flag = true;
        });
        $(this).addClass("current");
        $(this).siblings().removeClass("current ");
    });
})